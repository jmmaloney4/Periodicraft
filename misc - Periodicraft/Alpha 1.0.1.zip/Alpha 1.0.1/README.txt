{\rtf1\ansi\ansicpg1252\cocoartf1187\cocoasubrtf340
\cocoascreenfonts1{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww19080\viewh15080\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\b\fs24 \cf0 **Periodicraft README** Version Alpha 1.0.1\
\

\fs28 Periodicraft is Copyrighted:\
Copyright 2013\'a9 Jack Maloney, Noah Schoolman & Will Peterson\
\
Please Read the LICENSE.txt file for complete Terms
\fs24  and Conditions.\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\fs36 \cf0 How To Install Periodicraft:
\fs24 \
\
> Have Forge Installed\
> Find the Folder 
\i\b0 Code\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\i0\b \cf0 > Copy The folder, 
\i\b0 minecraft
\i0\b , \ul  \ulnone do not copy the outside folder 
\i\b0 Code
\i0\b \
> Go To Your 
\i\b0 %appdata% 
\i0\b (windows), or your 
\i\b0 Application Support
\i0\b  (MAC) Folder\
> go to 
\i\b0 .minecraft 
\i0\b (Windows) Or 
\i\b0 minecraft 
\i0\b (MAC)\
> Find the 
\i\b0 Mods
\i0\b  folder\
> Paste the folder you copied at the beginning, into this folder. \
> Go to the 
\i\b0 Jar
\i0\b  folder and copy all the files \ul inside\ulnone \
>Paste them inside of your 
\i\b0 minecraft.jar}